class ChannelList{
  String name;
  String type;

  ChannelList(this.name, this.type);
}